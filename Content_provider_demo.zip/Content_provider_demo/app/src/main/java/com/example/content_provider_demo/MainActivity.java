package com.example.content_provider_demo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Telephony;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.content_provider_demo.SmsAdapter;
import com.example.content_provider_demo.SmsModel;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_READ_SMS = 100;
    private RecyclerView smsRecyclerView;
    private SmsAdapter smsAdapter;
    private List<SmsModel> smsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        smsRecyclerView = findViewById(R.id.smsRecyclerView);
        smsList = new ArrayList<>();
        smsAdapter = new SmsAdapter(this, smsList);
        smsList.add(new SmsModel("Người gửi A", "Nội dung tin nhắn A"));
        smsList.add(new SmsModel("Người gửi B", "Nội dung tin nhắn B"));
        smsAdapter.notifyDataSetChanged();

        smsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        smsRecyclerView.setAdapter(smsAdapter);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_SMS},
                    PERMISSION_REQUEST_READ_SMS);
        } else {
            loadSmsMessages();
        }
    }

    private void loadSmsMessages() {
        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String address = cursor.getString(cursor.getColumnIndex(Telephony.Sms.ADDRESS));
                @SuppressLint("Range") String body = cursor.getString(cursor.getColumnIndex(Telephony.Sms.BODY));
                smsList.add(new SmsModel(address, body));
            } while (cursor.moveToNext());
            smsAdapter.notifyDataSetChanged();
            cursor.close();
        }
    }
}
