package com.example.content_provider_demo;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SmsAdapter extends RecyclerView.Adapter<SmsAdapter.SmsViewHolder> {

    private List<SmsModel> smsList;
    private Context context;

    public SmsAdapter(Context context, List<SmsModel> smsList) {
        this.context = context;
        this.smsList = smsList;
    }

    @NonNull
    @Override
    public SmsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sms, parent, false);
        return new SmsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SmsViewHolder holder, int position) {
        SmsModel sms = smsList.get(position);
        holder.senderTextView.setText(sms.getSender());
        holder.bodyPreviewTextView.setText(sms.getBodyPreview());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, SmsDetailActivity.class);
            intent.putExtra("sender", sms.getSender());
            intent.putExtra("body", sms.getBody());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return smsList.size();
    }

    public static class SmsViewHolder extends RecyclerView.ViewHolder {
        TextView senderTextView, bodyPreviewTextView;

        public SmsViewHolder(@NonNull View itemView) {
            super(itemView);
            senderTextView = itemView.findViewById(R.id.senderTextView);
            bodyPreviewTextView = itemView.findViewById(R.id.bodyPreviewTextView);
        }
    }

}

