package com.example.content_provider_demo;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SmsDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_detail);

        TextView senderTextView = findViewById(R.id.senderDetailTextView);
        TextView bodyTextView = findViewById(R.id.bodyDetailTextView);

        String sender = getIntent().getStringExtra("sender");
        String body = getIntent().getStringExtra("body");

        senderTextView.setText(sender);
        bodyTextView.setText(body);
    }
}

