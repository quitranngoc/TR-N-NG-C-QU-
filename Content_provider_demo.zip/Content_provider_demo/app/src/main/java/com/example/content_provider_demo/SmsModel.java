package com.example.content_provider_demo;


public class SmsModel {
    private String sender;
    private String body;

    public SmsModel(String sender, String body) {
        this.sender = sender;
        this.body = body;
    }

    public String getSender() {
        return sender;
    }

    public String getBody() {
        return body;
    }

    public String getBodyPreview() {
        return body.length() > 30 ? body.substring(0, 30) + "..." : body;
    }
}

